# Chatwork Mention to Team

# これはなに？

Chatworkではチーム機能がありますが、チームにメンションする仕組みがありません。 Chrome拡張機能で、グループチャットに設定されているチームメンバーごとにTOを送る拡張です。

# 動作イメージ

![image](https://user-images.githubusercontent.com/33831717/140536973-a1b5edbf-7c90-4331-bdbc-281922f36755.png)
